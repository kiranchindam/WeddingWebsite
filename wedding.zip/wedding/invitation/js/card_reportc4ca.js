(function($){
	$(function(){
		// box-shadow: 2px 4px 4px #ccc;

		// var report='<style type="text/css">.weui_mask{position: fixed;z-index: 899;display:none;width: 100%;height: 100%;top: 0;left: 0;background: rgba(0,0,0,.6);}#report0,#report1 {background-color: #fff;border-radius: 5px;}#report0 {display:none;width: 260px;position: fixed;top: 30px;left: 50%;margin-left: -130px;z-index: 999;padding-bottom: 20px;font-weight: 300;font-family: \'Microsoft Yahei\',Tahoma,Helvetica,Arial,sans-serif;}#report1 {width: 100%;height: 40%;/* top: 20%; */z-index: 1000;position: relative;}.tip,.verifyCode {position: absolute}#report2 {width: 100%;background-color: #f66;color: #fff;text-align: center;padding: 15px 0}#report2 h1 {font-size: 16px;margin-top: 10px}#report3 {margin-top: 20px;width: 100%;text-align: center}#report3 ul{margin: 0;padding: 0;}#report3 ul li {font-size: 15px;line-height: 40px;list-style: none;}#report3 ul li span {padding-right: 20px}#report3 li.active span {color: #f66;background: url(images/jubao_07.png) right no-repeat;padding-right: 20px;background-size: 15px}#report4 a,.tip {color: #fff;text-align: center}#report4 {text-align: center;margin-top: 10px}#report4 a {display: inline-block;width: 140px;height: 30px;line-height: 30px;font-size: 14px;border-radius: 3px;background-color: #f66}.close_label{position: absolute;top: 0px;left: 0px;display: block;opacity:0.9;background: #FFFFFF;color: #000000;padding: 3px 10px;text-align: center;border-bottom-right-radius:5px;font-weight: bold;font-size:18px;}</style><div class="weui_mask" id="select_mask"></div><div id="report0"><div id="report1"><div id="report2"><span class="close_label">X</span><p><img src="images/jubao_03.png" width="50px;"></p><h1>请选择举报原因</h1></div><div id="report3"><ul id="reportList"><li value="180" class="active"><span>色情、赌博、毒品</span></li><li value="181" class=""><span>谣言、社会负面、诈骗</span></li><li value="182" class=""><span>邪教、非法集会、传销</span></li><li value="183"><span>医药、整形、虚假广告</span></li><li value="184"><span>有奖集赞和关注转发</span></li><li value="185"><span>违反国家政策和法律</span></li><li value="34054"><span>其他原因</span></li></ul></div><div id="report4"><a id="reportSubmit" data-reason="色情、赌博、毒品" data-event="11203">提交举报</a></div></div></div>';
		// $("body").append(report);

		window.cid = "";
		$("#jubao_btn").click(function(){
			window.cid=$(this).attr("data-cid");
			$("#select_mask").fadeIn();
			$("#report0").fadeIn();
		});

		$(".close_label").click(function(){
			$("#select_mask").fadeOut();
			$("#report0").fadeOut();
		});

		$("#reportList").find("li").click(function(e){
			e.stopPropagation();
			$("#reportList").find("li").removeClass("active");
			$(this).addClass("active");
			$("#reportSubmit").attr("data-reason",$(this).text());
		});

		$("#reportSubmit").one("click",function(){
			var reason=$(this).attr("data-reason");
			$.post("card_report.php",{cid:window.cid,reason:reason},function(data){
				
				var lang_do_ok = $("#lang_do_ok").val();
				alert(lang_do_ok);
				
				$("#select_mask").fadeOut();
				$("#report0").fadeOut();
			});
		});

        $("#select_mask").bind("click", function () {
            $("#select_mask").fadeOut();
            $("#report0").fadeOut();
            event.stopPropagation();
        });

	});
})(jQuery);